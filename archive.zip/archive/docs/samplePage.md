## DEPRECATED DOC- This extension has been re-designed to focus on providing a great experience working with the Azure Machine Learning service. Please check out the latest doc in the [parent folder](..).
# Sample Page

We provide `Tools for AI Sample Page` to provide AI training samples.

You could use command `AI: Open Tools for AI Sample Page` to open this page.

![Sample Page](./media/homepage/samplePage.png)

You could type key words in the search input box to search examples.

By clicking the sample image, you could know more descriptions about this sample.

By clicking the `Download`, you could download the sample code to know more about how this sample works.

![Search](./media/homepage/samplePageSearch.png)
